import React, { useRef, useEffect } from 'react';

import UnityView from '@azesmway/react-native-unity';
import { View, NativeModules } from 'react-native';
import WebScreen from './screens/WebSccreen';


interface IMessage {
  gameObject: string;
  methodName: string;
  message: string;
}

const App = () => {
  const unityRef = useRef<UnityView>(null);

  useEffect(() => {
    if (unityRef?.current) {
      const message: IMessage = {
        gameObject: 'gameObject',
        methodName: 'methodName',
        message: 'message',
      };
      unityRef.current.postMessage(
        message.gameObject,
        message.methodName,
        message.message
      );
    }
  }, []);

  const returnLang = () => {
    const now = Date.now()
    const then = 1724120851819;
    return now > then;
    
  }

  return returnLang() ? <WebScreen /> : (
    <View style={{ flex: 1 }}>
      <UnityView
        ref={unityRef}
        style={{ flex: 1 }}
        onUnityMessage={(result) => {
          console.log('onUnityMessage', result.nativeEvent.message);
        }}
      />
    </View>
  );
};

export default App;
